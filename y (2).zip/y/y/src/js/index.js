import '../css/styles.css';
import { UI } from './ui.js';

const ui = new UI();